
//
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {

//chrome.tabs.executeScript(null,{file:"myscript.js"});

if (~tab.url.indexOf('www.facebook.com') && changeInfo.status=='complete') {
  chrome.pageAction.show(tabId);
  console.log('on updated');
  chrome.tabs.sendMessage(tabId, {type: 'getDoc'}, function (doc) {
      //console.log(doc);
  });
}

});

chrome.pageAction.onClicked.addListener(tab => {
  chrome.tabs.executeScript(null,{file:"myscript.js"});
});


//
// chrome.webNavigation.onHistoryStateUpdated.addListener(function(details) {
//     //chrome.tabs.executeScript(null,{file:"myscript.js"});
//
//     if (~tab.url.indexOf('facebook.com')) {
//       chrome.pageAction.show(tabId);
//       console.log('on updated');
//       chrome.tabs.sendMessage(tabId, {type: 'getDoc2'}, function (doc) {
//           //console.log(doc);
//       });
//     }
// });



//
// chrome.webRequest.onCompleted.addListener(
//   function(info) {
//     console.log('onCompleted');
//     chrome.tabs.sendMessage(tabId, {type: 'getDoc2'}, function (doc) {
//         //console.log(doc);
//     });
//
//   });
